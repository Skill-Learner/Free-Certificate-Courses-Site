"use strict";
// @ts-ignore
try {
    self['workbox:routing:6.0.2'] && _();
} catch (e) {}