< !doctype html > < html > < head > < meta charset = "utf-8" > < meta http - equiv = "cache-control"
content = "no-cache" > < style > body {
    visibility: hidden;
} < /style></head > < body > < /body></html >